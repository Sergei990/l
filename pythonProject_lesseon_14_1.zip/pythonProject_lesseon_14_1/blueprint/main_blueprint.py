from flask import Flask, Blueprint, render_template, request
from utils import Main_tabl

main_tabl = Main_tabl()
main_blueprint = Blueprint('main_blueprint', __name__, template_folder='templates')


@main_blueprint.get('/')
def index():
    return render_template('index.html')


@main_blueprint.get('/title/')
def enter_the_movie_name():
    return render_template('title.html')


@main_blueprint.get('/title/list/')
def get_dict_movie_by_title():
    word = request.args.get('word')
    return main_tabl.title_movie(word)


@main_blueprint.get('/movie/release/')
def films_sorti_bt_year():
    return render_template('release_year.html')


@main_blueprint.get('/movie/year/')
def get_films():
    year_one = int(request.args.get('year_one'))
    year_two = int(request.args.get('year_two'))
    result_films = main_tabl.release_the_movies(year_one, year_two)
    return result_films


@main_blueprint.get('/rating/children/')
def for_children():
    no_limit_by_age = ('G')
    return main_tabl.age_restrictions(no_limit_by_age)


@main_blueprint.get('/rating/family/')
def for_family():
    family = ('G', 'PG', 'PG-13')
    return main_tabl.age_restrictions(family)


@main_blueprint.get('/rating/adult/')
def for_adult():
    adult = ('R', 'NC-17')
    return main_tabl.age_restrictions(adult)


@main_blueprint.get('/genre/')
def sorti_film_by_genre():
    return render_template('genre.html')


@main_blueprint.get('/sort/genre/')
def get_film_by_genre():
    word = request.args.get('word')
    return main_tabl.name_genre(word)


@main_blueprint.get('/cast/')
def get_actors():
    actors_one = 'Rose McIver'
    actors_two = 'Ben Lamb'
    return main_tabl.actors(actors_one, actors_two)


@main_blueprint.get('/movie/type/')
def movie_by_typ():
    return render_template('get_type.html')


@main_blueprint.get('/movie/by_type/')
def get_movie_by_typ():
    typ_movie = request.args.get('type_movie')
    year = request.args.get('year')
    genre = request.args.get('genre')
    return main_tabl.typ_film(typ_movie, year, genre)
