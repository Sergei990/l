from flask import Flask, Blueprint

from blueprint.main_blueprint import main_blueprint

add = Flask(__name__)

add.register_blueprint(main_blueprint)

if __name__ == '__main__':
    add.run(host='127.0.0.1', port=8000, debug=True)
