import sqlite3
from sqlite3 import OperationalError

from flask import json


class Main_tabl:

    def title_movie(self, word):
        """Возвращает словарь фильмов по названию, года релиза и описанию."""
        try:

            with sqlite3.connect('./netflix.db') as file:
                file.row_factory = sqlite3.Row

                get_title_movie = file.execute(f"""
                                                    SELECT title, country, release_year, listed_in, description 
                                                    FROM netflix
                                                    WHERE title LIKE '{word}%'
                                                    ORDER BY release_year
                                                    """)
            title = get_title_movie.fetchall()
            main_dict = {}
            for item in title:
                main_dict = dict(item)

            return main_dict
        except OperationalError:
            return 'Не допустимый символ'

    def release_the_movies(self, year_one, year_two):
        """Возвращает фильмы по названию и года релиза"""
        with sqlite3.connect('./netflix.db') as file:
            file.row_factory = sqlite3.Row

        movie_release = file.execute(f"""
                                        SELECT title, release_year
                                        FROM netflix
                                        WHERE release_year BETWEEN  {year_one} AND {year_two}
                                        LIMIT 100
                                        """)
        the_films = movie_release.fetchall()
        list_of_films = []
        for items in the_films:
            result_films_by_release = dict(items)
            list_of_films.append(result_films_by_release)
        return list_of_films

    def age_restrictions(self, limit_age):
        """Возвращает название , возрастные ограничение, описание к фильмам"""
        with sqlite3.connect('./netflix.db') as file:
            file.row_factory = sqlite3.Row
            if len(limit_age) == 1:
                get_age = file.execute(f"""
                                    SELECT title, rating, description 
                                    FROM netflix 
                                    WHERE rating = '{limit_age}'
             
                                    """)
            else:
                get_age = file.execute(f"""
                                        SELECT title, rating, description
                                        FROM netflix 
                                        WHERE rating IN {limit_age}
                                        """)
        result_films_by_age = get_age.fetchall()

        list_films = []

        for items in result_films_by_age:
            films_by_age = dict(items)
            list_films.append(films_by_age)
        return list_films

    def name_genre(self, word):
        """Возвращает название, опесание фильмов"""
        with sqlite3.connect('./netflix.db') as file:
            file.row_factory = sqlite3.Row

        film_by_genre = file.execute(f"""
                                        SELECT title, description
                                        FROM netflix 
                                        WHERE listed_in LIKE '%{word}%'
                                        ORDER BY release_year
                                        LIMIT 10
                                    """)
        get_films_by_genre = film_by_genre.fetchall()

        list_films = []
        for items in get_films_by_genre:
            result = dict(items)
            films = json.dumps(result, indent=4)
            list_films.append(films)
        return list_films

    def actors(self, name_one: str, name_two: str):
        """Возвращает список актеров"""
        with sqlite3.connect('./netflix.db') as file:
            file.row_factory = sqlite3.Row

        get_actor = file.execute(f"""
                                    SELECT "cast" as actor
                                    FROM netflix 
                                    WHERE actor LIKE '%{name_one}%' 
                                    AND actor LIKE '%{name_two}%'
                                    """)
        result_by_actors = get_actor.fetchall()
        print(result_by_actors)
        list_actors = []
        new_cast_list = []

        for items in result_by_actors:
            result_dict = dict(items)

            for key, value in result_dict.items():
                r = value.split(', ')

                r.remove(name_one)
                r.remove(name_two)
                list_actors.extend(r)

                for actor in list_actors:

                    count = list_actors.count(actor)
                    # Ищем актеров где повторяются больше 2 раз
                    if count > 2:
                        new_cast_list.append(actor)

        return list(set(new_cast_list))

    def typ_film(self, typ_film, year, genre):
        """Возвращает название, описание к фильму"""
        with sqlite3.connect('./netflix.db') as file:
            file.row_factory = sqlite3.Row

        typ_film = file.execute(f"""
                                    SELECT title, description
                                    FROM netflix
                                    WHERE type LIKE '{typ_film}%' AND release_year = {year} AND listed_in LIKE '{genre}%'
                                    """)
        get_film_by_typ = typ_film.fetchall()
        list_films = []
        for items in get_film_by_typ:
            result_by_typ = dict(items)

            list_films.append(json.dumps(result_by_typ, indent=4))
        return list_films
